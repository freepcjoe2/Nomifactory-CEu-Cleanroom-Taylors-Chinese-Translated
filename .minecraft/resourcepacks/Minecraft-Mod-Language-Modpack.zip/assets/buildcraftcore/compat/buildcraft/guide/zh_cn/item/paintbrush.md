<chapter name="item.paintbrush.name"/>
<lore>
在世界上的缤纷色彩使你叹为观止之余，不妨想象要是轻轻一笔便能改变方块的颜色该是怎样？
涂绘方块用以装饰是一个好的选择，但涂色也可以有实际用途，比如分隔管道。
</lore>
<no_lore>
颜料刷可用于将各种不同的方块涂绘成16色之一。
通常情况下，给方块涂色只是为了装饰作用，但是一些方块一经涂色就会具有特殊属性。
例如：给管道涂上不同的颜色就可使它们彼此隔离。
</no_lore>
<recipes_usages stack="buildcraftcore:paintbrush"/>