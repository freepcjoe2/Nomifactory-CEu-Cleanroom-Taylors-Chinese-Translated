<chapter name="item.wrenchItem.name"/>
<lore>
创造和使用机器能带来许多好处，然而有时需要改变它们的运转方式或面朝方向。
扳手提供了解决方案：可以通过右击来修改机器或许多方块的状态。
</lore>
<no_lore>
扳手是一种基础工具。通过点击来旋转和操纵方块、机器以及一些实体。
</no_lore>
<recipes_usages stack="buildcraftcore:wrench"/>
